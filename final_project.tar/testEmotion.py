from emotion_detection import emotion_detector 
import unittest

class testEmotion (unittest.TestCase):
    def test_emotion_detector(self):
        #test Joy
        run_1 = emotion_detector("I am glad this happened" )
        self.assertEqual(run_1 ['dom'], 'joy')

        #test Ang
        run_2 = emotion_detector("I am really mad about this")
        self.assertEqual(run_2 ['dom'], 'anger')

        #test Dis
        run_3 = emotion_detector("I feel disgusted just hearing about this")
        self.assertEqual(run_3 ['dom'], 'disgust')

        #test Sad
        run_4 = emotion_detector("I am so sad about this")
        self.assertEqual(run_4 ['dom'], 'sadness')

        #test Fer
        run_5 = emotion_detector("I am realy afraid that this will happen")
        self.assertEqual(run_5 ['dom'], 'fear')

    unittest.main()