from flask import Flask, render_template, request
from emotion_detection import emotion_detector

app = Flask("Emotion Detector")

@app.route("/emotionDetector")
def detectTool():

    preread = request.args.get('text_to_analyze')
    reading = emotion_detector(preread)

    curRead =   '''
                "For the given statement, 
                the system response is anger: \{reading['anger']}, 
                disgust: \{reading['disgust']}, fear: \{reading['fear']}, 
                joy: \{reading['joy']} and sadness: \{reading['sadness']}. 
                The dominant emotion is \{reading['dom']}."
                '''

    return curRead

@app.route("/")
def render_index():

    return render_template('index.html')

if __name__ == "__main__":
    app.run(host = "0.0.0.0", port = 5000)